#include "header.h"
#include "driverheader.h"

void Robot::RobotInit() {
  std::cout << "Hello World from Robot::RobotInit\n";
}

void Robot::RobotPeriodic() {
  std::cout << "Hello World from Robot::RobotPeriodic\n";
}
