#include <iostream>

void func();