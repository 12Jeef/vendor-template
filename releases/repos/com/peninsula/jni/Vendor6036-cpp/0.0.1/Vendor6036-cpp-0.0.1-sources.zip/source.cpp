#include "header.h"
#include "driverheader.h"

void func() {
  std::cout << "Hello World from source.cpp\n";
  c_doThing();
}
